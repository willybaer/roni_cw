CREATE VIEW pld_task_view AS
SELECT pld_task.id,
    pld_task.project_id,
    pld_task.assignee_id,
    pld_task.creator_id,
    pld_task.group_id,
    pld_task.title,
    pld_task.description,
    pld_task."position",
    pld_task.start_date,
    pld_task.end_date,
    pld_task.due_date,
    pld_task.state,
    pld_task.estimation,
    pld_task.priority,
    pld_task.modifier,
    pld_task.created,
    pld_task.modified,
    pld_task.deleted,
    pld_task.escalation
   FROM pld_task
  WHERE (pld_task.deleted IS NULL)