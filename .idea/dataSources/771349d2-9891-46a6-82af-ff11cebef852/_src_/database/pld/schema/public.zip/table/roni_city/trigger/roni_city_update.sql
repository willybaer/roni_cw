CREATE TRIGGER roni_city_update
BEFORE INSERT OR UPDATE ON roni_city
FOR EACH ROW EXECUTE PROCEDURE roni_update_modified()