CREATE TRIGGER pld_team_insert
BEFORE INSERT ON pld_team
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()