CREATE FUNCTION pld_update_modified () RETURNS trigger
	LANGUAGE plpgsql
AS $$
begin
	new.modified := current_timestamp;
	return new;
end;
$$
