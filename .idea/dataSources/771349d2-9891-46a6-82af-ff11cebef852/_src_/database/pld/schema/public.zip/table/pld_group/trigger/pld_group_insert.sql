CREATE TRIGGER pld_group_insert
BEFORE INSERT ON pld_group
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()