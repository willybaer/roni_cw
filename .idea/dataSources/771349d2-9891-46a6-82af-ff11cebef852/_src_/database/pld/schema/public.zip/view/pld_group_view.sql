CREATE VIEW pld_group_view AS
SELECT pld_group.id,
    pld_group.project_id,
    pld_group.name,
    pld_group.color,
    pld_group.modifier,
    pld_group.created,
    pld_group.modified,
    pld_group.deleted
   FROM pld_group
  WHERE (pld_group.deleted IS NULL)