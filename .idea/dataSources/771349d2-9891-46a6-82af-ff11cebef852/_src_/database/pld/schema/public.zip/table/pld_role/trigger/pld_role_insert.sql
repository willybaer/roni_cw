CREATE TRIGGER pld_role_insert
BEFORE INSERT ON pld_role
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()