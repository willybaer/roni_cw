CREATE VIEW pld_team_view AS
SELECT pld_team.id,
    pld_team.user_id,
    pld_team.name,
    pld_team.description,
    pld_team.subscription,
    pld_team.modifier,
    pld_team.created,
    pld_team.modified,
    pld_team.deleted
   FROM pld_team
  WHERE (pld_team.deleted IS NULL)