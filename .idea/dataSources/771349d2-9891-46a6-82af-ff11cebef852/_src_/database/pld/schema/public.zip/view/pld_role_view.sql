CREATE VIEW pld_role_view AS
SELECT pld_role.id,
    pld_role.name,
    pld_role.description,
    pld_role.modifier,
    pld_role.created,
    pld_role.modified,
    pld_role.deleted
   FROM pld_role
  WHERE (pld_role.deleted IS NULL)