CREATE TRIGGER roni_location_update
BEFORE INSERT OR UPDATE ON roni_location
FOR EACH ROW EXECUTE PROCEDURE roni_update_modified()