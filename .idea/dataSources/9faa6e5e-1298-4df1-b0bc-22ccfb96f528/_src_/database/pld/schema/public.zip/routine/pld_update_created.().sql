CREATE FUNCTION pld_update_created () RETURNS trigger
	LANGUAGE plpgsql
AS $$
begin
	new.created := current_timestamp;
	return new;
end;
$$
