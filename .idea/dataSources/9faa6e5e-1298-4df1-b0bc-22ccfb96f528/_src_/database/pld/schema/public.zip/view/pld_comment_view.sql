CREATE VIEW pld_comment_view AS
SELECT pld_comment.id,
    pld_comment.task_id,
    pld_comment.user_id,
    pld_comment.comment,
    pld_comment.modifier,
    pld_comment.created,
    pld_comment.modified,
    pld_comment.deleted
   FROM pld_comment
  WHERE (pld_comment.deleted IS NULL)