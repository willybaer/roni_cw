CREATE TRIGGER pld_project_insert
BEFORE INSERT ON pld_project
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()