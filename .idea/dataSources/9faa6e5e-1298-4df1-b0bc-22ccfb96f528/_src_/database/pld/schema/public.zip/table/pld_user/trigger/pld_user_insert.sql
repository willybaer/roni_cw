CREATE TRIGGER pld_user_insert
BEFORE INSERT ON pld_user
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()