CREATE TRIGGER pld_comment_insert
BEFORE INSERT ON pld_comment
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()