CREATE TRIGGER pld_comment_update
BEFORE INSERT OR UPDATE ON pld_comment
FOR EACH ROW EXECUTE PROCEDURE pld_update_modified()