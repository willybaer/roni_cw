CREATE TRIGGER pld_project_update
BEFORE INSERT OR UPDATE ON pld_project
FOR EACH ROW EXECUTE PROCEDURE pld_update_modified()