CREATE TRIGGER pld_payment_insert
BEFORE INSERT ON pld_payment
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()