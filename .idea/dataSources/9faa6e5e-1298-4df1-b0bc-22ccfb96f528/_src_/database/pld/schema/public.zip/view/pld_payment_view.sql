CREATE VIEW pld_payment_view AS
SELECT pld_payment.id,
    pld_payment.team_id,
    pld_payment.amount,
    pld_payment.from_date,
    pld_payment.until_date,
    pld_payment.payment_type,
    pld_payment.payment_account,
    pld_payment.payment_name,
    pld_payment.payment_expiration,
    pld_payment.modifier,
    pld_payment.created,
    pld_payment.modified,
    pld_payment.deleted
   FROM pld_payment
  WHERE (pld_payment.deleted IS NULL)