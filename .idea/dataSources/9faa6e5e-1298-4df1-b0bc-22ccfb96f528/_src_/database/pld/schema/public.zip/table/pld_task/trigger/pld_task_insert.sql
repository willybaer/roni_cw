CREATE TRIGGER pld_task_insert
BEFORE INSERT ON pld_task
FOR EACH ROW EXECUTE PROCEDURE pld_update_created()