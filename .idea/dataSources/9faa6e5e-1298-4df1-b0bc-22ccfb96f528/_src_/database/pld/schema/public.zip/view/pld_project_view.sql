CREATE VIEW pld_project_view AS
SELECT pld_project.id,
    pld_project.team_id,
    pld_project.user_id,
    pld_project.title,
    pld_project.description,
    pld_project.start_date,
    pld_project.end_date,
    pld_project.state,
    pld_project.modifier,
    pld_project.created,
    pld_project.modified,
    pld_project.deleted,
    pld_project.abbreviation
   FROM pld_project
  WHERE (pld_project.deleted IS NULL)