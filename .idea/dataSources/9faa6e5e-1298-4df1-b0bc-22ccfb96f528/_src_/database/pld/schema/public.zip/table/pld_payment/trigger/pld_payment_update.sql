CREATE TRIGGER pld_payment_update
BEFORE INSERT OR UPDATE ON pld_payment
FOR EACH ROW EXECUTE PROCEDURE pld_update_modified()