CREATE VIEW pld_user_view AS
SELECT pld_user.id,
    pld_user.media_id,
    pld_user.firstname,
    pld_user.lastname,
    pld_user.username,
    pld_user.password,
    pld_user.email,
    pld_user.modifier,
    pld_user.created,
    pld_user.modified,
    pld_user.deleted,
    pld_user.last_active_team_id
   FROM pld_user
  WHERE (pld_user.deleted IS NULL)