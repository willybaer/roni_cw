CREATE FUNCTION update_modified () RETURNS trigger
	LANGUAGE plpgsql
AS $$
begin
	new.modified_at := current_timestamp;
	return new;
end;
$$
